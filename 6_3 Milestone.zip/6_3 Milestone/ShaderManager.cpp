#include "ShaderManager.h"
#include <fstream>
#include <sstream>
#include <iostream>

// Constructor
ShaderManager::ShaderManager()
    : shaderProgram(0)
{
}

// Destructor
ShaderManager::~ShaderManager()
{
    if (shaderProgram != 0)
    {
        glDeleteProgram(shaderProgram);
    }
}

// Load shaders from files
void ShaderManager::LoadShaders(const std::string& vertexShaderFile, const std::string& fragmentShaderFile)
{
    std::string vertexShaderSource = readShaderFile(vertexShaderFile);
    std::string fragmentShaderSource = readShaderFile(fragmentShaderFile);
    createShaderProgram(vertexShaderSource, fragmentShaderSource);
}

// Use the compiled shader program
void ShaderManager::use()
{
    glUseProgram(shaderProgram);
}

// Utility functions to set uniform values in the shader
void ShaderManager::setIntValue(const std::string& name, int value) const
{
    glUniform1i(glGetUniformLocation(shaderProgram, name.c_str()), value);
}

void ShaderManager::setFloatValue(const std::string& name, float value) const
{
    glUniform1f(glGetUniformLocation(shaderProgram, name.c_str()), value);
}

void ShaderManager::setVec4Value(const std::string& name, const glm::vec4& value) const
{
    glUniform4fv(glGetUniformLocation(shaderProgram, name.c_str()), 1, &value[0]);
}

void ShaderManager::setMat4Value(const std::string& name, const glm::mat4& value) const
{
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, name.c_str()), 1, GL_FALSE, &value[0][0]);
}

// Read shader source code from file
std::string ShaderManager::readShaderFile(const std::string& shaderFile)
{
    std::ifstream file(shaderFile);
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

// Compile shader
GLuint ShaderManager::compileShader(GLenum type, const std::string& source)
{
    GLuint shader = glCreateShader(type);
    const char* sourceCStr = source.c_str();
    glShaderSource(shader, 1, &sourceCStr, nullptr);
    glCompileShader(shader);

    GLint success;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        char infoLog[512];
        glGetShaderInfoLog(shader, 512, nullptr, infoLog);
        std::cerr << "ERROR::SHADER::COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    return shader;
}

// Create and link shader program
void ShaderManager::createShaderProgram(const std::string& vertexShaderSource, const std::string& fragmentShaderSource)
{
    GLuint vertexShader = compileShader(GL_VERTEX_SHADER, vertexShaderSource);
    GLuint fragmentShader = compileShader(GL_FRAGMENT_SHADER, fragmentShaderSource);

    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);

    GLint success;
    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
    if (!success)
    {
        char infoLog[512];
        glGetProgramInfoLog(shaderProgram, 512, nullptr, infoLog);
        std::cerr << "ERROR::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
    }

    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
}
