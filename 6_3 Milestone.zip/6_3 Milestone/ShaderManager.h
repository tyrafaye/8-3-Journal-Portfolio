#pragma once

#include <string>
#include <glm/glm.hpp>
#include <GL/glew.h>

class ShaderManager
{
public:
    // Constructor
    ShaderManager();
    // Destructor
    ~ShaderManager();

    // Load shaders from files
    void LoadShaders(const std::string& vertexShaderFile, const std::string& fragmentShaderFile);
    // Use the compiled shader program
    void use();

    // Utility functions to set uniform values in the shader
    void setIntValue(const std::string& name, int value) const;
    void setFloatValue(const std::string& name, float value) const;
    void setVec4Value(const std::string& name, const glm::vec4& value) const;
    void setMat4Value(const std::string& name, const glm::mat4& value) const;

private:
    // Read shader source code from file
    std::string readShaderFile(const std::string& shaderFile);

    // Compile shader
    GLuint compileShader(GLenum type, const std::string& source);

    // Create and link shader program
    void createShaderProgram(const std::string& vertexShaderSource, const std::string& fragmentShaderSource);

    // Shader program ID
    GLuint shaderProgram;
};
